package br.com.alura.aula03.exercicios;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Function;

public class Teste {

	public static void main(String[] args) {

		List<String> palavras = new ArrayList<>();
		Comparator<String> comparador = new ComparadorPorTamanho();
		Function<String, Integer> funcao = new FuncaoOrdenaPorTamanho();
		Function<String, Integer> funcaoLambda = s -> s.length();
		Function<String, Integer> funcaoMethodReference = String::length;
		
		Consumer<String> imprime = new ImprimeStrings();

		palavras.add("alura online");
		palavras.add("editora casa do código");
		palavras.add("caelum");

		palavras.sort(Comparator.comparing(funcao));
		
		palavras.forEach(imprime);


	}

}

class ComparadorPorTamanho implements Comparator<String> {
	@Override
	public int compare(String s1, String s2) {
		return s1.length() - s2.length();
	}

}

class ImprimeStrings implements Consumer<String> {
	@Override
	public void accept(String s) {
		System.out.println(s);
	}
}

class FuncaoOrdenaPorTamanho implements Function<String, Integer> {
	@Override
	public Integer apply(String s) {
		return s.length();
	}
	
}
