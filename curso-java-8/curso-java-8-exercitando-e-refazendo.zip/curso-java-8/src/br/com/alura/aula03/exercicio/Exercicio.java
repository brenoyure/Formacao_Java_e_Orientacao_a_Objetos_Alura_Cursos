package br.com.alura.aula03.exercicio;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Function;

public class Exercicio {

    public static void main(String[] args) {

        List<String> palavras = new ArrayList<>();

        palavras.add("alura online");
        palavras.add("editora casa do código");
        palavras.add("caelum");

        Function<String, Integer> funcao = s -> s.length();
        Comparator<String> comparador = (s1, s2) -> s1.length() - s2.length();
        

        palavras.sort(Comparator.comparing(funcao));
        palavras.sort(comparador);
        palavras.forEach(System.out::println);












    }

}
