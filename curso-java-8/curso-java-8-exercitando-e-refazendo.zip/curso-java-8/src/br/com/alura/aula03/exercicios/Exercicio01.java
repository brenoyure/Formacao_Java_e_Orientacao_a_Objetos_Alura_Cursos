package br.com.alura.aula03.exercicios;

import java.util.ArrayList;
import static java.util.Comparator.comparing;	// Import Static
import java.util.List;

public class Exercicio01 {

	public static void main(String[] args) {

		List<String> palavras = new ArrayList<>();

		palavras.add("alura online");
		palavras.add("editora casa do código");
		palavras.add("caelum");

//		palavras.sort(Comparator.comparing(s -> s.length())); // Lambda
//		palavras.sort(Comparator.comparing(String::length));  // MethodReference
		palavras.sort(comparing(String::length));			  // Import Static com MethodReference
		palavras.sort(comparing(s -> s.length()));			  // Import Static com Lambda
		
		palavras.forEach(s -> System.out.println(s));		  // println com Lambda
		palavras.forEach(System.out::println);				  // println com MethodReference

	}

}
