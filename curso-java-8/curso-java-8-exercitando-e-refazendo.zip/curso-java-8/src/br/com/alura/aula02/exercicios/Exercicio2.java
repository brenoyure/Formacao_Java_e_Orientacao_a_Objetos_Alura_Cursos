package br.com.alura.aula02.exercicios;

public class Exercicio2 {

	public static void main(String[] args) {

		new Thread(() -> System.out.println("Executando um Runnable")).start();

	}

}
