package br.com.alura.aula01.exercicio;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.function.Consumer;

public class Exercicio01 {

	public static void main(String[] args) {

		// Alura Online, Casa do Código e Caelum

		List<String> palavras = new ArrayList<>();

		palavras.add("alura online");
		palavras.add("casa do código");
		palavras.add("caelum");

		Consumer<String> comedorDeStrings = new ImprimeStrings();
		Comparator<String> ordenaPeloTamanho = new ComparadorPorTamanho();
		
		palavras.sort(ordenaPeloTamanho);

		palavras.forEach(comedorDeStrings);

	}

}

class ComparadorPorTamanho implements Comparator<String> {
	@Override
	public int compare(String s1, String s2) {
		return Integer.compare(s1.length(), s2.length());
	}
}

class ImprimeStrings implements Consumer<String> {
	@Override
	public void accept(String s) {
		System.out.println(s);
	}
}